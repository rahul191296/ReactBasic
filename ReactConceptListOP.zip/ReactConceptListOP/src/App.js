import React, { Component } from 'react';
import Person from "./Person/Person";

import './App.css';

class App extends Component {
  state = {
    persons: [
      {id: 'r1' , name: 'max' , age: 28},
      {id: 'r2' , name: 'manu' , age: 29},
      {id: 'r3' , name: 'stephnie' , age: 26}
    ],
    showPersons: false
  
}
   deletePersonHandler = (personIndex) => {
     const persons = this.state.persons.slice();
     persons.splice(personIndex , 1);
     this.setState({persons: persons});
   }

   togglePersonHandler = () => {
  //   console.log("button is clicked");
     const doesShow = this.state.showPersons;
     this.setState({showPersons: !doesShow});
  //   console.log(doesShow);
   }

  nameChangeHandler = (event , id) => {
      const personIndex =  this.state.persons.findIndex(p => {   //find person index
          return p.id === id;
        });
        const person = {                                // store  changed person in a variable 
          ...this.state.persons[personIndex]
        };
        person.name = event.target.value;                       // change the person name in person variable
        const persons = [...this.state.persons];                      
        persons[personIndex] = person;
        this.setState({ persons : persons});

  }
render()  {
  let persons = null;

  if (this.state.showPersons) {
    persons = (
      <div>
        {this.state.persons.map((person , index ) => {
           return <Person 
                click = { () => this.deletePersonHandler(index)}
                name = { person.name}
                 age = {person.age} 
                 id = { person.id} 
                 changed = {(event) => this.nameChangeHandler(event , person.id)}  />
                }
                )} 
      </div>
    );
  }

 return (
   <div>
    <button onClick = {this.togglePersonHandler}> Toggle Person </button>
      {persons}
   </div>
 );

}

}
export default App;
