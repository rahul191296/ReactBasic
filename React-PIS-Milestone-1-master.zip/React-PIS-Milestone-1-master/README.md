Step 1) npm install 
Step 2) npm install -g json-server //install json server
Step 3) npm install -g create-react-app  //install create-react-app
Step 4) npm install --save react-router //install router
Step 5) npm install axios  //install axios
Step 6) npm install --save react-chartjs-2   // Install react-chartjs-2
Step 7) json-server --watch products.json --port 3006  /Start Json Server on port 3006
Step 8) npm Start  // Application will start on port 3005
