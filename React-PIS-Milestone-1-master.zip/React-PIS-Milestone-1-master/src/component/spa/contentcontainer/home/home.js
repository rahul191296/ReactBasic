import React from 'react';


class Home extends React.Component {
   
    render() { 
        return ( 
            <div class="divhome">
                <img class="imgradius" src="https://chandan-share.s3.amazonaws.com/pis.jpg"></img>
                <h3>In business terms, inventory management means the right stock, at the right levels, in the right place, at the right time, and at the right cost as well as price.</h3>
            </div>
         );
    }
}
 
export default Home;