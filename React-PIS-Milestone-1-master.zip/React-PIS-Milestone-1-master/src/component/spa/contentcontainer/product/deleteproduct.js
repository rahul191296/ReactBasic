import React from 'react';



class DeleteProduct extends React.Component {
   
    render() { 
        return ( 
            <div>
                 
            <h1>This is Delete Product!</h1>
            </div>
         );
    }
}
 
export default DeleteProduct;